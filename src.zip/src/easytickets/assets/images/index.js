const images = {
    logo: require("./logo.svg"),

    soccerball: require("./soccer-ball.svg"),
    creditcard: require("./credit-card.svg"),

    arena: require("./arena.svg"),
    trophy: require("./trophy.svg"),
    ticket: require("./ticket.svg"),

    edit: require("./edit.svg"),
    delete: require("./delete.svg"),

    loading: require("./loading.gif"),
    processStep: require("./process-step.svg"),

    soccer: require("./soccer.svg"),
    checked: require("./checked.svg"),

}

export default images;