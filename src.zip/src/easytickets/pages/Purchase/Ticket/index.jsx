import React, { Component } from 'react';
import "./styles.css"

class Ticket extends Component {
    render(){
        return;
    }
}

export default Ticket;